-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.27 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             8.0.0.4396
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for pk_db
DROP DATABASE IF EXISTS `pk_db`;
CREATE DATABASE IF NOT EXISTS `pk_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pk_db`;


-- Dumping structure for table pk_db.tabelgejala
DROP TABLE IF EXISTS `tabelgejala`;
CREATE TABLE IF NOT EXISTS `tabelgejala` (
  `KodeGejala` char(10) NOT NULL,
  `NamaGejala` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tabelgejala: ~13 rows (approximately)
/*!40000 ALTER TABLE `tabelgejala` DISABLE KEYS */;
INSERT INTO `tabelgejala` (`KodeGejala`, `NamaGejala`) VALUES
	('PK0001', 'Gatal'),
	('PK0002', 'ketombe'),
	('PK0003', 'kulit merah'),
	('PK0004', 'gizi buruk'),
	('PK0005', 'cairan telinga'),
	('PK0006', 'rontok'),
	('PK0007', 'botak'),
	('PK0008', 'bersin'),
	('PK0009', 'diare'),
	('PK0010', 'gelisah'),
	('PK0011', 'bintik'),
	('PK0012', 'berkerak'),
	('PK0013', 'gatal telinga');
/*!40000 ALTER TABLE `tabelgejala` ENABLE KEYS */;


-- Dumping structure for table pk_db.tabelpenyakit
DROP TABLE IF EXISTS `tabelpenyakit`;
CREATE TABLE IF NOT EXISTS `tabelpenyakit` (
  `KodePenyakit` char(6) NOT NULL,
  `NamaPenyakit` char(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tabelpenyakit: ~6 rows (approximately)
/*!40000 ALTER TABLE `tabelpenyakit` DISABLE KEYS */;
INSERT INTO `tabelpenyakit` (`KodePenyakit`, `NamaPenyakit`) VALUES
	('P0001', 'Ring Worm'),
	('P0002', 'Kulit Kering'),
	('P0003', 'Infeksi Jamur'),
	('P0004', 'Alergi Demartitis'),
	('P0005', 'Kutu'),
	('P0006', 'Rambut Rontok');
/*!40000 ALTER TABLE `tabelpenyakit` ENABLE KEYS */;


-- Dumping structure for table pk_db.tabelpertanyaan
DROP TABLE IF EXISTS `tabelpertanyaan`;
CREATE TABLE IF NOT EXISTS `tabelpertanyaan` (
  `KodePertanyaan` varchar(6) NOT NULL,
  `Pertanyaan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tabelpertanyaan: ~12 rows (approximately)
/*!40000 ALTER TABLE `tabelpertanyaan` DISABLE KEYS */;
INSERT INTO `tabelpertanyaan` (`KodePertanyaan`, `Pertanyaan`) VALUES
	('T0001', 'Apakah kucing anda gatal dan menggaruk-garuk tubuh'),
	('T0002', 'Apakah kulit kucing anda memiliki ketombe'),
	('T0003', 'Apakah kulit kucing anda merah-merah?'),
	('T0004', 'Apakah kucing anda memiliki gizi buruk?'),
	('T0005', 'Apakah telinga kucing anda mengeluarkan cairan?'),
	('T0006', 'Apakah kucing anda mengalami kebotakan?'),
	('T0007', 'Apakah kucing anda bersin-bersin?'),
	('T0008', 'Apakah kucing anda mengalami diare?'),
	('T0009', 'Apakah kucing anda terlihat gelisah'),
	('T0010', 'Apakah kulit kucing anda berbintik?'),
	('T0011', 'Apakah kulit kucing anda berkerak?'),
	('T0012', 'Apakah kucing anda gatal pada bagian telinga?');
/*!40000 ALTER TABLE `tabelpertanyaan` ENABLE KEYS */;


-- Dumping structure for table pk_db.tabelrule
DROP TABLE IF EXISTS `tabelrule`;
CREATE TABLE IF NOT EXISTS `tabelrule` (
  `KodeRule` varchar(6) NOT NULL,
  `kodepertanyaan1` varchar(50) DEFAULT NULL,
  `kodepenyakit` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tabelrule: ~6 rows (approximately)
/*!40000 ALTER TABLE `tabelrule` DISABLE KEYS */;
INSERT INTO `tabelrule` (`KodeRule`, `kodepertanyaan1`, `kodepenyakit`) VALUES
	('R0001', 'T0001,T0002,T0003', 'P0001'),
	('R0002', 'T0002,T0004', 'P0002'),
	('R0003', 'T0005,T0007', 'P0003'),
	('R0004', 'T0001,T0006,T0008,T0009', 'P0004'),
	('R0005', 'T0001,T0010,T0011,T0012', 'P0005'),
	('R0006', 'T0001,T0006,T0004,T0010', 'P0006');
/*!40000 ALTER TABLE `tabelrule` ENABLE KEYS */;


-- Dumping structure for table pk_db.tb_login
DROP TABLE IF EXISTS `tb_login`;
CREATE TABLE IF NOT EXISTS `tb_login` (
  `id_login` varchar(4) NOT NULL,
  `Pass_Login` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tb_login: ~3 rows (approximately)
/*!40000 ALTER TABLE `tb_login` DISABLE KEYS */;
INSERT INTO `tb_login` (`id_login`, `Pass_Login`) VALUES
	('1234', '1111'),
	('5678', '2222'),
	('1245', '3333');
/*!40000 ALTER TABLE `tb_login` ENABLE KEYS */;


-- Dumping structure for table pk_db.tb_user
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE IF NOT EXISTS `tb_user` (
  `id_login` varchar(4) NOT NULL,
  `pass_login` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pk_db.tb_user: ~1 rows (approximately)
/*!40000 ALTER TABLE `tb_user` DISABLE KEYS */;
INSERT INTO `tb_user` (`id_login`, `pass_login`) VALUES
	('1234', '1111');
/*!40000 ALTER TABLE `tb_user` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

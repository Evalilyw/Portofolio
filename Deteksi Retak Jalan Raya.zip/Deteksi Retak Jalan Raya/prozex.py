# -*- coding: utf-8 -*-
"""
Created on Wed May 16 03:10:30 2018

@author: asus
"""


import cv2
import numpy as np 
from matplotlib import pyplot as plt

img = cv2.imread('jalan3.jpg')
#greyscale
print img 
H,W = img.shape[:2]
grey = np.zeros((H,W), np.uint8)

for i in range(H):
    for j in range(W):
         grey[i,j] = np.clip(0.50 * img[i,j,0] + 0.50 *
    img[i,j,1] + 0.50 * img[i,j,2], 0, 255)
               

 #thresholding
ret,thresh1 = cv2.threshold(grey,127,255,cv2.THRESH_BINARY)
ret,thresh2 = cv2.threshold(grey,127,255,cv2.THRESH_BINARY_INV)
ret,thresh3 = cv2.threshold(grey,127,255,cv2.THRESH_TRUNC)
ret,thresh4 = cv2.threshold(grey,127,255,cv2.THRESH_TOZERO)
ret,thresh5 = cv2.threshold(grey,127,255,cv2.THRESH_TOZERO_INV)

titles = ['Original Image','BINARY','BINARY_INV','TRUNC','TOZERO','TOZERO_INV']
images = [img, thresh1, thresh2, thresh3, thresh4, thresh5]

for i in xrange(6):
    plt.subplot(2,3,i+1),plt.imshow(images[i],'gray')
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])

    
#medianfilter

final = thresh1[:]
for y in range (len(thresh1)):
    for x in range (y):
        final[y,x] = thresh1[y,x]
    
members = [thresh1[0,0]] * 9
for y in range (1,len(thresh1)-1):
    for x in range (1,y-1):
        members[0] = thresh1[y-1,x-1]
        members[1] = thresh1[y,x-1]
        members[2] = thresh1[y+1,x-1]
        members[3] = thresh1[y-1,x]
        members[4] = thresh1[y,x]
        members[5] = thresh1[y+1,x]
        members[6] = thresh1[y-1, x+1]
        members[7] = thresh1[y,x+1]
        members[8] = thresh1[y+1,x+1]
        
        members.sort()
        final[y,x]=members[4]
#closing
kernel = np.ones((5,5), np.uint8)
erosi = cv2.morphologyEx(thresh1, cv2.MORPH_CLOSE, kernel)

plt.subplot(131), plt.imshow(img,cmap ='gray')
plt.title('Citra Awal'), plt.xticks([]), plt.yticks([])
plt.subplot(132), plt.imshow(thresh1,cmap ='gray')
plt.title('Citra Biner'), plt.xticks([]), plt.yticks([])
plt.subplot(133), plt.imshow(erosi,cmap ='gray')
plt.title('Hasil'), plt.xticks([]), plt.yticks([])
cv2.imshow('RGB', img)
cv2.imshow('Hasil', erosi)
cv2.waitKey()
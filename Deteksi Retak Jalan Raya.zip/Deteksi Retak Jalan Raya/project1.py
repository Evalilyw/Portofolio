# -*- coding: utf-8 -*-
"""
Created on Tue May 15 22:21:22 2018

@author: User
"""

import cv2
import numpy as np 
from matplotlib import pyplot as plt

img = cv2.imread('jalan1.jpg')
#greyscale
print img 
H,W = img.shape[:2]
grey = np.zeros((H,W), np.uint8)

for i in range(H):
    for j in range(W):
        grey[i,j] = np.clip(0.07 * img[i,j,0] + 0.72 *
    img[i,j,1] + 0.21 * img[i,j,2], 0, 255)
               
cv2.imshow("RGB",img)
cv2.imshow("Grayscale", grey)

 #thresholding
ret,thresh1 = cv2.threshold(grey,127,255,cv2.THRESH_BINARY)
ret,thresh2 = cv2.threshold(grey,127,255,cv2.THRESH_BINARY_INV)
ret,thresh3 = cv2.threshold(grey,127,255,cv2.THRESH_TRUNC)
ret,thresh4 = cv2.threshold(grey,127,255,cv2.THRESH_TOZERO)

titles = ['Original Image','BINARY','BINARY_INV','TRUNC','TOZERO']
images = [img, thresh1, thresh2, thresh3, thresh4]

for i in xrange(6):
    plt.subplot(2,3,i+1),plt.imshow(images[i],'gray')
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
    
cv2.imshow("Threshold", thresh1)
    
#medianfilter

    
cv2.waitKey()